create extension if not exists pgcrypto;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  surname text,
  phone text,
  address text,
  is_admin boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create type shipment_direction as enum ('out','in');
create type approval_status as enum ('pending','approved','rejected');
create type shipment_status as enum ('created','paid','label_created','pickup_scheduled','in_transit','delivered','canceled','rts');

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  direction shipment_direction not null,
  service text not null check (service in ('EIED','EIDL')),
  dest text not null check (dest in ('KSA','KWI','QAT','BAH','OMN')),
  pickup_mode text not null check (pickup_mode in ('pickup','dropoff')),
  pickup_address text,
  weight_kg numeric(10,2) not null,
  length_cm numeric(10,1) default 0,
  width_cm numeric(10,1) default 0,
  height_cm numeric(10,1) default 0,
  chargeable_kg numeric(10,2) not null,
  item_category text not null,
  item_desc text not null,
  amount_base numeric(12,2) not null,
  amount_fuel numeric(12,2) not null,
  amount_gpa numeric(12,2) not null,
  amount_pickup numeric(12,2) not null,
  amount_margin numeric(12,2) not null,
  amount_vat numeric(12,2) not null,
  amount_total numeric(12,2) not null,
  invoice_url text,
  approval approval_status default 'pending',
  status shipment_status default 'created',
  awb text,
  label_pdf_url text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  provider text not null default 'nomod',
  amount numeric(12,2) not null,
  currency text not null default 'AED',
  status text not null,
  link_url text,
  external_id text,
  raw jsonb,
  created_at timestamptz default now()
);

create table if not exists public.tracking_events (
  id bigserial primary key,
  awb text not null,
  code text,
  description text,
  location text,
  event_time timestamptz,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.shipments enable row level security;
alter table public.payments enable row level security;

create policy profiles_self on public.profiles
  for select using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy profiles_admin on public.profiles
  for all using (exists (select 1 from public.profiles p where p.user_id = auth.uid() and p.is_admin))
  with check (exists (select 1 from public.profiles p where p.user_id = auth.uid() and p.is_admin));

create policy shipments_self_select on public.shipments
  for select using (auth.uid() = user_id);
create policy shipments_self_insert on public.shipments
  for insert with check (auth.uid() = user_id);
create policy shipments_self_update on public.shipments
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy shipments_admin on public.shipments
  for all using (exists (select 1 from public.profiles p where p.user_id = auth.uid() and p.is_admin))
  with check (exists (select 1 from public.profiles p where p.user_id = auth.uid() and p.is_admin));

create policy payments_self_select on public.payments for select using (
  exists (select 1 from public.shipments s where s.id = payments.shipment_id and s.user_id = auth.uid())
);
create policy payments_admin on public.payments for all using (exists (select 1 from public.profiles p where p.user_id = auth.uid() and p.is_admin));