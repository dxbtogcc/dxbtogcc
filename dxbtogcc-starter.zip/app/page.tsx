export default function Home(){
  return (
    <div className="card" style={{maxWidth:680}}>
      <h1>Ship from DXB to GCC</h1>
      <p className="muted">Fast quotes, UAE pickup, no COD, receiver pays destination duties.</p>
      <ul>
        <li>Login with UAE mobile (OTP)</li>
        <li>Create shipment & pay via Nomod link</li>
        <li>Track via SMSA</li>
      </ul>
      <a className="btn" href="/new-shipment" style={{marginTop:12, display:'inline-block'}}>Start a Shipment</a>
    </div>
  )
}