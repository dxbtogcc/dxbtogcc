'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase-browser';
import { quote } from '@/lib/quote';
import { isUaeMobile } from '@/utils/uaePhone';

type Direction = 'out'|'in';
type Service = 'EIED'|'EIDL';
type Dest = 'KSA'|'KWI'|'QAT'|'BAH'|'OMN';

const badWords = ['food','snack','chocolate','drink','meat','perishable','grocery','spice','tea','coffee'];

export default function NewShipment(){
  const supabase = supabaseBrowser();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string>('');

  const [direction, setDirection] = useState<Direction>('out');
  const [service, setService] = useState<Service>('EIED');
  const [dest, setDest] = useState<Dest>('KSA');

  const [kg, setKg] = useState<number>(1);
  const [len, setLen] = useState<number>(0);
  const [wid, setWid] = useState<number>(0);
  const [hei, setHei] = useState<number>(0);

  const [pickupMode, setPickup] = useState<'pickup'|'dropoff'>('pickup');
  const [pickupAddr, setPickupAddr] = useState('');

  const [itemCat, setItemCat] = useState('Documents');
  const [itemDesc, setItemDesc] = useState('');

  const [rcvName, setRcvName] = useState('');
  const [rcvPhone, setRcvPhone] = useState('');
  const [rcvAddr, setRcvAddr] = useState('');

  const invoiceRef = useRef<HTMLInputElement|null>(null);
  const [terms, setTerms] = useState(false);
  const [isPosting, setPosting] = useState(false);

  useEffect(()=>{ (async()=>{
    const { data: { user } } = await supabase.auth.getUser();
    if(!user){ window.location.href = '/login'; return; }
    if(!isUaeMobile(user.phone)){ setError('UAE mobile (+9715XXXXXXXX) required'); return; }
    setReady(true);
  })() },[]);

  const chg = useMemo(()=>{
    const vol = (len>0 && wid>0 && hei>0) ? (len*wid*hei)/5000 : 0;
    return Math.max(kg, vol);
  }, [kg, len, wid, hei]);

  const q = useMemo(()=> quote({ direction, service, dest, pickupMode, kg, len, wid, hei }), [direction, service, dest, pickupMode, kg, len, wid, hei]);

  const invalidItem = useMemo(()=>{
    const d = (itemDesc||'').toLowerCase();
    return itemCat === 'Food' || badWords.some(w=>d.includes(w));
  }, [itemCat, itemDesc]);

  const canSubmit = ready && !invalidItem && terms && q.total > 0 && !!rcvName && !!rcvPhone && !!rcvAddr;

  const uploadInvoice = async (shipmentId: string) => {
    const file = invoiceRef.current?.files?.[0];
    if(!file) return null;
    const { data: { user } } = await supabase.auth.getUser();
    if(!user) throw new Error('Not signed in');
    const path = `invoices/${user.id}/${shipmentId}-${Date.now()}-${file.name}`;
    const { error: upErr } = await supabase.storage.from('invoices').upload(path, file, { cacheControl: '3600', upsert: false });
    if(upErr) throw upErr;
    await fetch('/api/shipments/invoice', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ shipment_id: shipmentId, path }) })
    return path;
  };

  const submit = async () => {
    if(!canSubmit) return;
    setPosting(true);
    setError('');

    try{
      const r = await fetch('/api/shipments', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          direction, service, dest,
          kg, len, wid, hei,
          pickup_mode: pickupMode,
          pickup_address: pickupAddr,
          item_cat: itemCat,
          item_desc: itemDesc,
          rcv_name: rcvName,
          rcv_phone: rcvPhone,
          rcv_addr: rcvAddr
        })
      });
      const j = await r.json();
      if(!r.ok){ throw new Error(j?.error || 'Failed to create shipment'); }
      const shipment = j.shipment;

      await uploadInvoice(shipment.id);

      const pay = await fetch('/api/nomod/link', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ shipment_id: shipment.id })
      });
      const pj = await pay.json();
      if(pj?.link){ window.open(pj.link, '_blank'); }
      else { alert('We will send you a payment link shortly.'); }

      window.location.href = '/dashboard';
    }catch(e:any){
      setError(e?.message || 'Something went wrong');
    }finally{
      setPosting(false);
    }
  };

  if(!ready) return <div className="container" style={{padding:'10vh 20px'}}>Loading… {error && <p style={{color:'#b91c1c'}}>{error}</p>}</div>;

  return (
    <div style={{display:'grid',gridTemplateColumns:'minmax(0,1.05fr) minmax(0,.95fr)',gap:16}}>
      <section className="card">
        <h2>New Shipment</h2>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div>
            <label>Direction</label>
            <select value={direction} onChange={e=>setDirection(e.target.value as Direction)}>
              <option value="out">Outbound — UAE ➜ GCC</option>
              <option value="in">Inbound — GCC ➜ UAE</option>
            </select>
          </div>
          <div>
            <label>Service</label>
            <select value={service} onChange={e=>setService(e.target.value as Service)}>
              <option value="EIED">Economy</option>
              <option value="EIDL">Lite</option>
            </select>
          </div>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12, marginTop:8}}>
          <div>
            <label>Destination</label>
            <select value={dest} onChange={e=>setDest(e.target.value as Dest)}>
              <option value="KSA">KSA</option>
              <option value="KWI">Kuwait</option>
              <option value="QAT">Qatar</option>
              <option value="BAH">Bahrain</option>
              <option value="OMN">Oman</option>
            </select>
          </div>
          <div>
            <label>Declared Value (optional)</label>
            <input placeholder="0.00" inputMode="decimal" />
          </div>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12, marginTop:8}}>
          <div>
            <label>Actual Weight (kg)</label>
            <input type="number" min="0.01" step="0.01" value={kg} onChange={e=>setKg(parseFloat(e.target.value||'0'))}/>
          </div>
          <div>
            <label>Chargeable (auto)</label>
            <input value={`${chg.toFixed(2)} kg`} readOnly />
          </div>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12, marginTop:8}}>
          <div>
            <label>Length (cm)</label>
            <input type="number" min="0" step="0.1" value={len} onChange={e=>setLen(parseFloat(e.target.value||'0'))}/>
          </div>
          <div>
            <label>Width (cm)</label>
            <input type="number" min="0" step="0.1" value={wid} onChange={e=>setWid(parseFloat(e.target.value||'0'))}/>
          </div>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12, marginTop:8}}>
          <div>
            <label>Height (cm)</label>
            <input type="number" min="0" step="0.1" value={hei} onChange={e=>setHei(parseFloat(e.target.value||'0'))}/>
          </div>
          <div>
            <label>UAE Pickup / Drop-Off</label>
            <select value={pickupMode} onChange={e=>setPickup(e.target.value as 'pickup'|'dropoff')}>
              <option value="pickup">Pickup anywhere in UAE (AED 60)</option>
              <option value="dropoff">Drop at Dragon Mart 2, Shop GC70 (Free)</option>
            </select>
          </div>
        </div>

        <div style={{marginTop:8}}>
          <label>Pickup Address (if Pickup)</label>
          <input placeholder="Building, street, area, emirate" value={pickupAddr} onChange={e=>setPickupAddr(e.target.value)} />
        </div>

        <div className="hr" />

        <h3>Item Details</h3>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div>
            <label>Category</label>
            <select value={itemCat} onChange={e=>setItemCat(e.target.value)}>
              <option>Documents</option>
              <option>Apparel</option>
              <option>Electronics</option>
              <option>Cosmetics</option>
              <option>Accessories</option>
              <option>Books</option>
              <option>Home Goods</option>
              <option>Other</option>
              <option disabled>Food / Perishables — Not Allowed</option>
            </select>
          </div>
          <div>
            <label>Item Name / Description</label>
            <input placeholder="Example: T-shirts, phone case (no batteries)" value={itemDesc} onChange={e=>setItemDesc(e.target.value)} />
          </div>
        </div>

        <div style={{marginTop:8}}>
          <label>Upload Invoice (PDF/JPG/PNG)</label>
          <input type="file" accept=".pdf,image/*" ref={invoiceRef}/>
          <p className="muted" style={{marginTop:4}}>Optional but recommended for customs clearance.</p>
        </div>

        <div className="hr" />

        <h3>Receiver</h3>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div>
            <label>Full Name</label>
            <input value={rcvName} onChange={e=>setRcvName(e.target.value)} />
          </div>
          <div>
            <label>Phone</label>
            <input value={rcvPhone} onChange={e=>setRcvPhone(e.target.value)} />
          </div>
        </div>
        <div style={{marginTop:8}}>
          <label>{direction==='out' ? 'Receiver Address (GCC)' : 'Delivery Address (UAE)'}</label>
          <textarea value={rcvAddr} onChange={e=>setRcvAddr(e.target.value)} />
        </div>

        <div style={{marginTop:12, display:'flex', gap:8, alignItems:'start'}}>
          <input type="checkbox" checked={terms} onChange={e=>setTerms(e.target.checked)} style={{marginTop:4}} />
          <span className="muted">
            I confirm no prohibited items (including food/perishables). Receiver pays destination duties/taxes. No COD collected.
          </span>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr', gap:12, marginTop:12}}>
          <button className="btn" onClick={submit} disabled={!canSubmit || isPosting}>
            {isPosting ? 'Processing…' : 'Create & Pay via Nomod'}
          </button>
          <a className="btn" href="/dashboard" style={{background:'#fff', color:'var(--primary)'}}>Cancel</a>
        </div>

        {error && <p style={{color:'#b91c1c', marginTop:8}}>{error}</p>}
      </section>

      <aside className="card">
        <h2>Your Quote (AED)</h2>
        <div className="total"><span className="muted">Base</span><span className="mono">{q.b.toFixed(2)}</span></div>
        <div className="total"><span className="muted">Fuel 10%</span><span className="mono">{q.fuel.toFixed(2)}</span></div>
        <div className="total"><span className="muted">GPA (≥2 or 10%)</span><span className="mono">{q.gpa.toFixed(2)}</span></div>
        <div className="total"><span className="muted">UAE Pickup</span><span className="mono">{q.pickup.toFixed(2)}</span></div>
        <div className="total"><span className="muted">Our Margin 10%</span><span className="mono">{q.margin.toFixed(2)}</span></div>
        <div className="total"><span className="muted">VAT 5%</span><span className="mono">{q.vat.toFixed(2)}</span></div>
        <div className="hr" />
        <div className="total" style={{borderWidth:2}}><span>Total (Pay Now)</span><span className="mono">{q.total.toFixed(2)}</span></div>
      </aside>
    </div>
  )
}