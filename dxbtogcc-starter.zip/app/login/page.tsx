'use client';
import { useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase-browser';
import { isUaeMobile } from '@/utils/uaePhone';

export default function Login(){
  const supabase = supabaseBrowser();
  const [phone, setPhone] = useState('+971');
  const [sent, setSent] = useState(false);
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState('');

  const send = async () => {
    if(!isUaeMobile(phone)) return setMsg('Enter mobile like +9715XXXXXXXX');
    const { error } = await supabase.auth.signInWithOtp({ phone });
    setMsg(error ? error.message : 'OTP sent by SMS'); setSent(!error);
  };

  const verify = async () => {
    const { error } = await supabase.auth.verifyOtp({ phone, token: code, type: 'sms' });
    if(error){ setMsg(error.message); return }
    window.location.href = '/dashboard';
  };

  return (
    <div className="container" style={{maxWidth:420, margin:'10vh auto'}}>
      <h1>Sign in with UAE Mobile</h1>
      <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+9715XXXXXXXX" />
      {!sent ? (
        <button onClick={send} className="btn" style={{marginTop:12}}>Send OTP</button>
      ) : (
        <div style={{marginTop:12}}>
          <input value={code} onChange={e=>setCode(e.target.value)} placeholder="6-digit OTP" />
          <button onClick={verify} className="btn" style={{marginTop:12}}>Verify & Continue</button>
        </div>
      )}
      {msg && <p className="muted" style={{marginTop:8}}>{msg}</p>}
    </div>
  )
}