import './globals.css'
import type { Metadata } from 'next'
import { brand } from './theme'
import Link from 'next/link'

export const metadata: Metadata = {
  title: `${brand.name} — Ship UAE ⇄ GCC`,
  description: 'Accounts, UAE phone OTP, Nomod payment links, tracking, and admin approvals.',
  metadataBase: new URL(brand.url),
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en"><body>
      <nav className="nav">
        <div className="container" style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:12}}>
          <Link href="/" style={{display:'flex',alignItems:'center',gap:10,fontWeight:800}}>
            <img src="/logo.svg" alt={brand.name} width={24} height={24} />
            <span>{brand.name}</span>
          </Link>
          <div style={{display:'flex',gap:10}}>
            <Link href="/new-shipment">New Shipment</Link>
            <Link href="/dashboard">Dashboard</Link>
            <Link href="/admin">Admin</Link>
            <Link href="/login">Login</Link>
          </div>
        </div>
      </nav>
      <main className="container">{children}</main>
      <footer className="container" style={{color:'var(--muted)',borderTop:'1px solid var(--line)',marginTop:20,paddingTop:12}}>
        © {new Date().getFullYear()} {brand.name} · <a href={`mailto:${brand.email}`}>{brand.email}</a>
      </footer>
    </body></html>
  )
}