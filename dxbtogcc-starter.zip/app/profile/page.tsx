'use client';
import { useEffect, useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase-browser';

export default function Profile(){
  const supabase = supabaseBrowser();
  const [full_name,setFull] = useState('');
  const [surname,setSur] = useState('');
  const [address,setAddr] = useState('');
  const [msg,setMsg] = useState('');

  useEffect(()=>{ (async()=>{
    const { data: { user } } = await supabase.auth.getUser(); if(!user) return;
    const { data } = await supabase.from('profiles').select('full_name,surname,address').eq('user_id', user.id).maybeSingle();
    if(data){ setFull(data.full_name||''); setSur(data.surname||''); setAddr(data.address||'') }
  })() },[]);

  const save = async()=>{
    const { data: { user } } = await supabase.auth.getUser(); if(!user) return;
    const { error } = await supabase.from('profiles').upsert({ user_id: user.id, full_name, surname, address });
    setMsg(error? error.message : 'Saved');
  };

  return (
    <div className="container" style={{maxWidth:560, margin:'8vh auto'}}>
      <h1>My Details</h1>
      <label>First Name</label><input value={full_name} onChange={e=>setFull(e.target.value)} />
      <label>Surname</label><input value={surname} onChange={e=>setSur(e.target.value)} />
      <label>Address</label><textarea value={address} onChange={e=>setAddr(e.target.value)} />
      <button onClick={save} className="btn" style={{marginTop:12}}>Save</button>
      {msg && <p className="muted">{msg}</p>}
    </div>
  )
}