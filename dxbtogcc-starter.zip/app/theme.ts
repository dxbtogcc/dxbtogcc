export const brand = {
  name: 'DXB to GCC',
  url: 'https://dxbtogcc.com',
  email: 'support@dxbtogcc.com',
  colors: {
    primary: '#111827',
    text: '#0b1220',
    muted: '#6b7280',
    line: '#e5e7eb',
    bg: '#ffffff',
  }
}