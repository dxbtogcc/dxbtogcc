export type QuoteInput = {
  direction: 'out'|'in'
  service: 'EIED'|'EIDL'
  dest: 'KSA'|'KWI'|'QAT'|'BAH'|'OMN'
  pickupMode: 'pickup'|'dropoff'
  kg: number
  len: number
  wid: number
  hei: number
}

const MARGIN = 0.10
const VAT = 0.05
const UAE_PICKUP_FEE = 60

const EIDL_OUT = { first: 27, add: 7 }
const EIDL_RET = { first: 18, add: 6 }
const EIED_OUT: any = { KSA:{base:[[.5,22.4],[1,26.3],[1.5,31.2],[2,36.2],[2.5,40.6],[3,44.7],[3.5,49.1],[4,53.5],[4.5,57.2],[5,60.8]], add:3.7}, KWI:{base:[[.5,23.7],[1,27.5],[1.5,32.4],[2,37.3],[2.5,41.6],[3,46.0],[3.5,50.4],[4,54.8],[4.5,58.4],[5,62.1]], add:4.2}, BAH:{base:[[.5,21.3],[1,26.3],[1.5,31.2],[2,36.2],[2.5,40.6],[3,44.7],[3.5,49.1],[4,53.5],[4.5,57.2],[5,60.8]], add:3.1}, OMN:{base:[[.5,20.8],[1,25.1],[1.5,29.3],[2,33.6],[2.5,37.3],[3,40.9],[3.5,44.7],[4,48.1],[4.5,51.3],[5,54.3]], add:3.6}, QAT:{base:[[.5,20.2],[1,23.4],[1.5,27.6],[2,31.8],[2.5,35.4],[3,39.1],[3.5,42.9],[4,46.6],[4.5,49.7],[5,52.8]], add:3.6} }
const EIED_RET: any = { KSA:{base:[[.5,19.1],[1,22.4],[1.5,26.6],[2,30.8],[2.5,34.6],[3,38.0],[3.5,41.8],[4,45.5],[4.5,48.7],[5,51.7]], add:3.2}, KWI:{base:[[.5,20.2],[1,23.4],[1.5,27.6],[2,31.8],[2.5,35.4],[3,39.1],[3.5,42.9],[4,46.6],[4.5,49.7],[5,52.8]], add:3.6}, BAH:{base:[[.5,18.2],[1,22.4],[1.5,26.6],[2,30.8],[2.5,34.6],[3,38.0],[3.5,41.8],[4,45.5],[4.5,48.7],[5,51.7]], add:2.7}, OMN:{base:[[.5,17.7],[1,21.4],[1.5,25.0],[2,28.6],[2.5,31.8],[3,34.8],[3.5,38.0],[4,40.9],[4.5,43.7],[5,46.2]], add:3.1}, QAT:{base:[[.5,20.2],[1,23.4],[1.5,27.6],[2,31.8],[2.5,35.4],[3,39.1],[3.5,42.9],[4,46.6],[4.5,49.7],[5,52.8]], add:3.6} }

const ceilHalf = (x:number)=> Math.ceil(x*2)/2
const vol = (l:number,w:number,h:number)=> (l>0&&w>0&&h>0) ? (l*w*h)/5000 : 0

function base(direction:'out'|'in', service:'EIED'|'EIDL', dest:string, kg:number){
  const w = Math.max(0, kg)
  if(service==='EIDL'){
    const t = direction==='out'? EIDL_OUT: EIDL_RET
    const chg = ceilHalf(w)
    const slabs = Math.max(1, Math.round(chg/0.5))
    return t.first + Math.max(0, slabs-1)*t.add
  }
  const tbl = (direction==='out'? EIED_OUT: EIED_RET)[dest]
  const chg = ceilHalf(w)
  if(chg<=5){ const f = tbl.base.find(([cw]:number[])=>cw===chg); return f? f[1]:0 }
  const addSlabs = Math.round((chg-5)/0.5)
  return tbl.base[tbl.base.length-1][1] + addSlabs*tbl.add
}

export function quote(input: QuoteInput){
  const chg = Math.max(input.kg, vol(input.len, input.wid, input.hei))
  const b = base(input.direction, input.service, input.dest, chg)
  const fuel = b*0.10
  const gpa = (chg>0 && chg<=30)? Math.max(2, (b+fuel)*0.10) : 0
  const pickup = (input.direction==='out' && input.pickupMode==='pickup')? UAE_PICKUP_FEE : 0
  const subtotal = b+fuel+gpa+pickup
  const margin = subtotal*MARGIN
  const preVat = subtotal+margin
  const vat = preVat*VAT
  const total = preVat+vat
  return { chg, b, fuel, gpa, pickup, margin, vat, total }
}